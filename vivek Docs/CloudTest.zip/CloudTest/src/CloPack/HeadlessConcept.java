package CloPack;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;

public class HeadlessConcept {
	public WebDriver driver;
	@BeforeClass
	public void BrowserLaunch(){
		 
	}

}
